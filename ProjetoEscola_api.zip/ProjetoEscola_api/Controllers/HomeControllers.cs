using Microsoft.AspNetCore.Mvc;
namespace ProjetoEscola_API.Controllers{
//atributos 
[ApiController] 

[Route("/")] //definindo a rota 
// a classe Controller base fornece funcionalidades para utilizar comunicação http.

public class HomeController: ControllerBase{
    [HttpGet]
public ActionResult Inicio(){
    return new ContentResult{
        ContentType = "text/html",
        Content = "<h1>API Projeto Escola: funcionou!!!!</h1>"
    };
  }
 }

}

